#include <iostream>
#include <unistd.h>
#include <ctime>
#include <random>

using namespace std;

#include "common.h"
#include "marshal.h"
#include "update.h"

//#define For(i,n) for (int i=0; i<n; i++)


Mapa mapa;
Stav stav; //vzdy som hrac cislo 0
Prikaz prikaz;

Bod kontroler(Bod pozicia, Bod rychlost, Bod cielovaPozicia) {
  Bod rozdielPozicie = cielovaPozicia - pozicia;
  Bod cielovaRychlost = rozdielPozicie * 0.5;

  // umele obmedzenie maximalnej rychlosti pre lepsiu kontrolu
  double pomerKMojejMaximalnejRychlosti = 150.0 / cielovaRychlost.dist();
  if (pomerKMojejMaximalnejRychlosti > 1.0) {
    cielovaRychlost = cielovaRychlost * pomerKMojejMaximalnejRychlosti;
  }

  Bod rozdielRychlosti = cielovaRychlost - rychlost;
  Bod cielovaAkceleracia = rozdielRychlosti * 5.0;
  return cielovaAkceleracia;
}

// main() zavola tuto funkciu, ked chce vediet, aky prikaz chceme vykonat,
// co tato funkcia rozhodne pomocou toho, ako nastavi prikaz;

/*pair<Bod,Bod> synch(int s){
   
  return {stav.hraci[s].obj.pozicia, stav.hraci[s].obj.rychlost-stav.hraci[0].rychlost};
}*/

int korist, citlivost, rage;
pair<int,int> P;
double r1;
// int r1=0;
 
Bod sprint(Bod k){
  return (k - stav.hraci[0].obj.pozicia);
  
}

int najblizsi(){
  int a;
  for(int i=1; i<stav.hraci.size(); i++)
    if (stav.hraci[i].obj.zivoty>0){
      a=i;
      break;
    }
  for(int i=a; i<stav.hraci.size(); i++)
    if (stav.hraci[i].obj.zivoty>0 && (stav.hraci[i].obj.pozicia-stav.hraci[0].obj.pozicia).dist()<(stav.hraci[a].obj.pozicia-stav.hraci[0].obj.pozicia).dist())
      a=i;
  return a;
}
bool mimomapy(Bod A)
{
  if(A.x<0 || A.y<0 || A.x>=mapa.w || A.y>=mapa.h)
    return false;
  return true;
}
Bod bachastena()
{
    Bod X=Bod(stav.hraci[0].obj.rychlost.x*stav.hraci[0].obj.rychlost.x,stav.hraci[0].obj.rychlost.y*stav.hraci[0].obj.rychlost.y)*(-1);
    Bod Y=Bod(-stav.hraci[0].obj.rychlost.y,stav.hraci[0].obj.rychlost.x);
    Bod Z=stav.hraci[0].obj.pozicia+stav.hraci[0].obj.rychlost*2;
  if(mimomapy(Z))
    return X+Y;
  else 
    return sprint(stav.hraci[korist].obj.pozicia);
}
Bod pozorobj()
{
  P={-1,-1};
  for(int j=0;j<5;j++){
    if(j==4)
      continue;

    for(int i=0;i<stav.obj[j].size();i++){
      if(P.first==-1){
        if(stav.obj[j][i].zivoty>0)
          P={j,i};
        continue;
      }
      if((stav.obj[j][i].pozicia-stav.hraci[0].obj.pozicia).dist()-stav.obj[j][i].polomer<(stav.obj[P.first][P.second].pozicia-stav.hraci[0].obj.pozicia).dist()-stav.obj[P.first][P.second].polomer && stav.obj[j][i].zivoty>0);
        P={j,i};
    }
  }
  if(P.first!=-1)
  {
    if(P.first==1)
      return stav.hraci[0].obj.rychlost*(-1);
    else 
      return stav.obj[P.first][P.second].rychlost;
  }
  else 
    return Bod(0,0);
}
void zistiTah() {
  citlivost=200;
  double r1=stav.hraci[0].obj.polomer;
  korist=najblizsi();
  prikaz.ciel=stav.hraci[korist].obj.pozicia-stav.hraci[0].obj.pozicia+stav.hraci[korist].obj.rychlost-stav.hraci[korist].obj.rychlost;
  Bod odsteny=bachastena(),odobj=pozorobj();
  prikaz.acc=odsteny*5+odobj;
  if(stav.hraci[0].obj.rychlost.dist()>200)prikaz.acc=prikaz.acc+(stav.hraci[0].obj.rychlost*(-1));
}






int main() {
  // v tejto funkcii su vseobecne veci, nemusite ju menit (ale mozte).

  unsigned seed = time(NULL) * getpid();
  srand(seed);

  nacitaj(cin,mapa);
  fprintf(stderr, "START pid=%d, seed=%u\n", getpid(), seed);

  while (cin.good()) {
    nacitaj(cin,stav);

    zistiTah();

    uloz(cout,prikaz);
    cout << endl;
  }
}
