#! /bin/bash

make
./server/server zaznamy/001 mapy/blank.map klienti/mapa klienti/mapa
sleep(5000)